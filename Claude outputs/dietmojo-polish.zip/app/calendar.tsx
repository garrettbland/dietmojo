import { AppText } from '@/components/ui/AppText'
import { Button } from '@/components/ui/Button'
import { IconButton } from '@/components/ui/IconButton'
import { Colors, Fonts, Radius, Spacing } from '@/constants/theme'
import { addDays, parseLocal } from '@/lib/date'
import { getLoggedDays, getStreak } from '@/lib/entries'
import { haptic } from '@/lib/haptics'
import { useDate } from '@/providers/DateProvider'
import Ionicons from '@expo/vector-icons/Ionicons'
import { useRouter } from 'expo-router'
import { useEffect, useState } from 'react'
import { Text, View } from 'react-native'
import DateTimePicker, {
    CalendarDay,
    DateType,
} from 'react-native-ui-datepicker'

export default function Calendar() {
    const router = useRouter()
    const { date, setDate } = useDate()
    const [logged, setLogged] = useState<Set<string>>(new Set())
    const [streak, setStreak] = useState(0)

    useEffect(() => {
        const today = new Date()
        getLoggedDays(addDays(today, -730), today).then(setLogged)
        getStreak().then((s) => setStreak(s.current))
    }, [])

    const select = (value: DateType) => {
        if (!value) return
        haptic.selection()
        const d =
            value instanceof Date
                ? value
                : typeof value === 'string'
                  ? parseLocal(value.replace(' ', 'T'))
                  : new Date(value as number)
        setDate(d)
        router.back()
    }

    const Day = (day: CalendarDay) => {
        const hasMeals = logged.has(day.date.slice(0, 10))
        return (
            <View
                style={{
                    width: 38,
                    height: 38,
                    borderRadius: 19,
                    alignItems: 'center',
                    justifyContent: 'center',
                    backgroundColor: day.isSelected
                        ? Colors.coral
                        : 'transparent',
                    borderWidth:
                        day.isToday && !day.isSelected ? 1.5 : 0,
                    borderColor: Colors.coral,
                    opacity: day.isDisabled
                        ? 0.3
                        : day.isCurrentMonth
                          ? 1
                          : 0.4,
                }}
            >
                <Text
                    style={{
                        fontFamily: day.isSelected
                            ? Fonts.extraBold
                            : Fonts.semiBold,
                        fontSize: 15,
                        color: day.isSelected
                            ? Colors.white
                            : Colors.text,
                    }}
                >
                    {day.text}
                </Text>
                <View
                    style={{
                        position: 'absolute',
                        bottom: 4,
                        width: 4,
                        height: 4,
                        borderRadius: 2,
                        backgroundColor: hasMeals
                            ? day.isSelected
                                ? Colors.white
                                : Colors.orange
                            : 'transparent',
                    }}
                />
            </View>
        )
    }

    return (
        <View
            style={{
                flex: 1,
                backgroundColor: Colors.white,
                paddingHorizontal: Spacing.lg,
                paddingTop: Spacing.xl,
            }}
        >
            <View
                style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    marginBottom: Spacing.xs,
                }}
            >
                <View>
                    <AppText variant="h2">History</AppText>
                    <AppText variant="caption" color={Colors.gray500}>
                        <Text style={{ color: Colors.orange }}>
                            ●
                        </Text>{' '}
                        days with meals · 🔥 {streak} day streak
                    </AppText>
                </View>
                <IconButton
                    icon="close"
                    accessibilityLabel="Close"
                    background={Colors.gray50}
                    size={38}
                    onPress={() => router.back()}
                />
            </View>

            <DateTimePicker
                mode="single"
                date={date}
                maxDate={new Date()}
                onChange={({ date: d }) => select(d)}
                components={{
                    Day,
                    IconPrev: (
                        <Ionicons
                            name="chevron-back"
                            size={22}
                            color={Colors.gray700}
                        />
                    ),
                    IconNext: (
                        <Ionicons
                            name="chevron-forward"
                            size={22}
                            color={Colors.gray700}
                        />
                    ),
                }}
                styles={{
                    header: { paddingVertical: 8 },
                    month_selector_label: {
                        fontFamily: Fonts.bold,
                        fontSize: 18,
                        color: Colors.text,
                    },
                    year_selector_label: {
                        fontFamily: Fonts.bold,
                        fontSize: 18,
                        color: Colors.coral,
                    },
                    weekday_label: {
                        fontFamily: Fonts.bold,
                        fontSize: 12,
                        color: Colors.gray500,
                    },
                    month_label: { fontFamily: Fonts.semiBold },
                    year_label: { fontFamily: Fonts.semiBold },
                    selected_month: {
                        backgroundColor: Colors.coral,
                        borderRadius: Radius.full,
                    },
                    selected_month_label: { color: Colors.white },
                    selected_year: {
                        backgroundColor: Colors.coral,
                        borderRadius: Radius.full,
                    },
                    selected_year_label: { color: Colors.white },
                }}
            />

            <Button
                title="Jump to today"
                variant="ghost"
                icon="today-outline"
                style={{ marginTop: Spacing.sm }}
                onPress={() => select(new Date())}
            />
        </View>
    )
}
