import { AppText } from '@/components/ui/AppText'
import { Button } from '@/components/ui/Button'
import { Segmented } from '@/components/ui/Chip'
import { TextField } from '@/components/ui/TextField'
import { Colors, Spacing } from '@/constants/theme'
import {
    formatLongDate,
    isToday,
    onDayAtCurrentTime,
    toLocalTimestamp,
} from '@/lib/date'
import { haptic } from '@/lib/haptics'
import {
    getMeasurementForDay,
    getMeasurements,
    upsertDailyMeasurement,
} from '@/lib/measurements'
import {
    getSettings,
    updateSettings,
    useSettings,
} from '@/lib/settings'
import {
    fromKg,
    parseNumber,
    sanitizeDecimal,
    toKg,
    WeightUnit,
} from '@/lib/units'
import { useDate } from '@/providers/DateProvider'
import { useRouter } from 'expo-router'
import { useEffect, useState } from 'react'
import { Alert, View } from 'react-native'

const Weight = () => {
    const router = useRouter()
    const { date } = useDate()
    const { weightUnit: unit } = useSettings()
    const [text, setText] = useState('')
    const [hint, setHint] = useState<string>()
    const [saving, setSaving] = useState(false)
    const [error, setError] = useState<string>()

    // Prefill with today's entry, or show last weight as a hint
    useEffect(() => {
        ;(async () => {
            const u = getSettings().weightUnit
            const existing = await getMeasurementForDay(
                'WEIGHT',
                date
            )
            if (existing) {
                setText(fromKg(existing.value, u).toFixed(1))
                return
            }
            const all = await getMeasurements('WEIGHT')
            const last = all[all.length - 1]
            if (last) {
                setHint(
                    `Last: ${fromKg(last.value, u).toFixed(1)} ${u}`
                )
            }
        })()
    }, [date])

    const changeUnit = (next: WeightUnit) => {
        const n = parseNumber(text)
        if (n != null) setText(fromKg(toKg(n, unit), next).toFixed(1))
        updateSettings({ weightUnit: next })
    }

    const save = async () => {
        const value = parseNumber(text)
        const maxValue = unit === 'lb' ? 1000 : 450
        if (value == null || value < 20 || value > maxValue) {
            haptic.warning()
            setError('Enter a valid weight')
            return
        }
        setSaving(true)
        const res = await upsertDailyMeasurement({
            measured_at: toLocalTimestamp(onDayAtCurrentTime(date)),
            type: 'WEIGHT',
            value: toKg(value, unit),
        })
        if (!res.ok) {
            setSaving(false)
            Alert.alert("Couldn't save", 'Please try again.')
            return
        }
        haptic.success()
        router.back()
    }

    return (
        <View
            style={{
                flex: 1,
                backgroundColor: Colors.white,
                padding: Spacing.lg,
                paddingTop: Spacing.xl,
                gap: Spacing.md,
            }}
        >
            <View>
                <AppText variant="h2">Log weight</AppText>
                <AppText variant="caption" color={Colors.gray500}>
                    {isToday(date) ? 'Today' : formatLongDate(date)}
                    {hint ? ` · ${hint}` : ''}
                </AppText>
            </View>

            <TextField
                size="lg"
                autoFocus
                placeholder="0.0"
                keyboardType="decimal-pad"
                value={text}
                onChangeText={(t) => {
                    setError(undefined)
                    setText(sanitizeDecimal(t))
                }}
                suffix={unit}
                error={error}
                maxLength={6}
                returnKeyType="done"
                onSubmitEditing={save}
                accessibilityLabel={`Weight in ${unit === 'lb' ? 'pounds' : 'kilograms'}`}
            />

            <Segmented
                options={[
                    { key: 'lb', label: 'lb' },
                    { key: 'kg', label: 'kg' },
                ]}
                value={unit}
                onChange={changeUnit}
            />

            <Button
                title="Save weight"
                icon="checkmark"
                size="lg"
                loading={saving}
                onPress={save}
            />
        </View>
    )
}

export default Weight
