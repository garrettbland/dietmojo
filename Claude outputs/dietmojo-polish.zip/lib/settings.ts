import Storage from 'expo-sqlite/kv-store'
import { useSyncExternalStore } from 'react'
import { WeightUnit } from './units'

/**
 * User settings, persisted with expo-sqlite's key-value store.
 * Read with useSettings(), write with updateSettings().
 */
export type Settings = {
    goals: {
        calories: number
        protein: number
        carbs: number
        fat: number
    }
    weightUnit: WeightUnit
    /** Which side the main action buttons sit on */
    handedness: 'right' | 'left'
    listStyle: 'comfortable' | 'compact'
    reminders: {
        enabled: boolean
        /** "HH:mm" 24h times */
        times: string[]
    }
}

export const DEFAULT_SETTINGS: Settings = {
    goals: { calories: 2000, protein: 150, carbs: 200, fat: 65 },
    weightUnit: 'lb',
    handedness: 'right',
    listStyle: 'comfortable',
    reminders: {
        enabled: false,
        times: ['08:30', '12:30', '18:30'],
    },
}

const KEY = 'settings:v1'

const load = (): Settings => {
    try {
        const raw = Storage.getItemSync(KEY)
        if (!raw) return DEFAULT_SETTINGS
        const parsed = JSON.parse(raw) as Partial<Settings>
        return {
            ...DEFAULT_SETTINGS,
            ...parsed,
            goals: { ...DEFAULT_SETTINGS.goals, ...parsed.goals },
            reminders: {
                ...DEFAULT_SETTINGS.reminders,
                ...parsed.reminders,
            },
        }
    } catch {
        return DEFAULT_SETTINGS
    }
}

let current: Settings | null = null
const listeners = new Set<() => void>()

export const getSettings = (): Settings => {
    if (!current) current = load()
    return current
}

export const updateSettings = (
    patch: Partial<Settings> | ((prev: Settings) => Partial<Settings>)
) => {
    const prev = getSettings()
    const changes = typeof patch === 'function' ? patch(prev) : patch
    current = { ...prev, ...changes }
    try {
        Storage.setItemSync(KEY, JSON.stringify(current))
    } catch (error) {
        console.warn('Could not save settings', error)
    }
    listeners.forEach((l) => l())
}

export const resetSettings = () => {
    try {
        Storage.removeItemSync(KEY)
    } catch {}
    current = DEFAULT_SETTINGS
    listeners.forEach((l) => l())
}

const subscribe = (listener: () => void) => {
    listeners.add(listener)
    return () => {
        listeners.delete(listener)
    }
}

export const useSettings = () =>
    useSyncExternalStore(subscribe, getSettings, getSettings)
