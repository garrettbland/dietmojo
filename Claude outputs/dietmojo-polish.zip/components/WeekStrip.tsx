import { Colors, Fonts, Radius } from '@/constants/theme'
import {
    addDays,
    isFuture,
    isSameDay,
    isToday,
    toDayKey,
} from '@/lib/date'
import { haptic } from '@/lib/haptics'
import { Pressable, Text, View } from 'react-native'

/**
 * The Sunday–Saturday week containing the selected day.
 * Dots mark days with meals logged; future days are disabled.
 */
export const WeekStrip = ({
    selected,
    onSelect,
    loggedDays,
}: {
    selected: Date
    onSelect: (d: Date) => void
    loggedDays: Set<string>
}) => {
    // Week (Sun–Sat) containing the selected day
    const start = addDays(selected, -selected.getDay())
    const days = Array.from({ length: 7 }, (_, i) =>
        addDays(start, i)
    )

    return (
        <View style={{ flexDirection: 'row', gap: 6 }}>
            {days.map((d) => {
                const active = isSameDay(d, selected)
                const future = isFuture(d)
                const logged = loggedDays.has(toDayKey(d))
                const today = isToday(d)
                return (
                    <Pressable
                        key={toDayKey(d)}
                        disabled={future}
                        accessibilityRole="button"
                        accessibilityState={{
                            selected: active,
                            disabled: future,
                        }}
                        accessibilityLabel={`${d.toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })}${logged ? ', has meals' : ''}`}
                        onPress={() => {
                            haptic.selection()
                            onSelect(d)
                        }}
                        style={{
                            flex: 1,
                            alignItems: 'center',
                            paddingVertical: 8,
                            borderRadius: Radius.lg,
                            backgroundColor: active
                                ? Colors.coral
                                : Colors.white,
                            opacity: future ? 0.4 : 1,
                            borderWidth: today && !active ? 1.5 : 0,
                            borderColor: Colors.coral,
                        }}
                    >
                        <Text
                            maxFontSizeMultiplier={1.2}
                            style={{
                                fontFamily: Fonts.bold,
                                fontSize: 11,
                                color: active
                                    ? 'rgba(255,255,255,0.9)'
                                    : Colors.gray500,
                            }}
                        >
                            {d
                                .toLocaleDateString(undefined, {
                                    weekday: 'short',
                                })
                                .slice(0, 3)
                                .toUpperCase()}
                        </Text>
                        <Text
                            maxFontSizeMultiplier={1.2}
                            style={{
                                fontFamily: Fonts.extraBold,
                                fontSize: 17,
                                marginTop: 2,
                                color: active
                                    ? Colors.white
                                    : Colors.text,
                            }}
                        >
                            {d.getDate()}
                        </Text>
                        <View
                            style={{
                                width: 5,
                                height: 5,
                                borderRadius: 3,
                                marginTop: 4,
                                backgroundColor: logged
                                    ? active
                                        ? Colors.white
                                        : Colors.orange
                                    : 'transparent',
                            }}
                        />
                    </Pressable>
                )
            })}
        </View>
    )
}
