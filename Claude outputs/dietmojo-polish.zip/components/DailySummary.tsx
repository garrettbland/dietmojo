import { Colors, Fonts, Radius } from '@/constants/theme'
import { Settings } from '@/lib/settings'
import { formatNumber } from '@/lib/units'
import { FoodEntry } from '@/types/types'
import { Text, View } from 'react-native'
import { AppText } from './ui/AppText'
import { Card } from './ui/Card'

export const sumEntries = (entries: FoodEntry[]) =>
    entries.reduce(
        (acc, e) => ({
            calories: acc.calories + (e.calories ?? 0),
            protein: acc.protein + (e.protein ?? 0),
            carbs: acc.carbs + (e.carbs ?? 0),
            fat: acc.fat + (e.fat ?? 0),
        }),
        { calories: 0, protein: 0, carbs: 0, fat: 0 }
    )

const Bar = ({ value, goal }: { value: number; goal: number }) => {
    const pct = goal > 0 ? Math.min(value / goal, 1) : 0
    return (
        <View
            style={{
                height: 8,
                borderRadius: Radius.full,
                backgroundColor: 'rgba(255,255,255,0.35)',
                overflow: 'hidden',
            }}
        >
            <View
                style={{
                    width: `${pct * 100}%`,
                    height: '100%',
                    borderRadius: Radius.full,
                    backgroundColor: Colors.white,
                }}
            />
        </View>
    )
}

const Macro = ({
    label,
    value,
    goal,
}: {
    label: string
    value: number
    goal: number
}) => (
    <View style={{ flex: 1, gap: 6 }}>
        <View
            style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignItems: 'baseline',
            }}
        >
            <AppText variant="label" color={Colors.white}>
                {label}
            </AppText>
            <Text
                maxFontSizeMultiplier={1.2}
                style={{
                    fontFamily: Fonts.bodySemiBold,
                    fontSize: 12,
                    color: 'rgba(255,255,255,0.9)',
                }}
            >
                {Math.round(value)}/{goal}g
            </Text>
        </View>
        <Bar value={value} goal={goal} />
    </View>
)

/** Gradient card with calories + macro progress for the day. */
export const DailySummary = ({
    entries,
    goals,
}: {
    entries: FoodEntry[]
    goals: Settings['goals']
}) => {
    const totals = sumEntries(entries)
    const remaining = goals.calories - totals.calories
    const over = remaining < 0

    return (
        <Card variant="gradient" padding={20}>
            <View
                style={{
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    alignItems: 'flex-end',
                }}
                accessible
                accessibilityLabel={`${Math.round(totals.calories)} of ${goals.calories} calories eaten. ${Math.abs(Math.round(remaining))} ${over ? 'over' : 'remaining'}.`}
            >
                <View>
                    <AppText
                        variant="label"
                        color="rgba(255,255,255,0.9)"
                    >
                        CALORIES
                    </AppText>
                    <View
                        style={{
                            flexDirection: 'row',
                            alignItems: 'baseline',
                            gap: 6,
                        }}
                    >
                        <AppText
                            variant="display"
                            color={Colors.white}
                        >
                            {formatNumber(
                                Math.round(totals.calories)
                            )}
                        </AppText>
                        <AppText
                            variant="body"
                            color="rgba(255,255,255,0.9)"
                        >
                            / {goals.calories}
                        </AppText>
                    </View>
                </View>
                <View
                    style={{
                        backgroundColor: 'rgba(255,255,255,0.25)',
                        borderRadius: Radius.full,
                        paddingHorizontal: 12,
                        paddingVertical: 6,
                        marginBottom: 6,
                    }}
                >
                    <AppText variant="label" color={Colors.white}>
                        {over
                            ? `${Math.abs(Math.round(remaining))} over`
                            : `${Math.round(remaining)} left`}
                    </AppText>
                </View>
            </View>

            <View style={{ marginTop: 12 }}>
                <Bar value={totals.calories} goal={goals.calories} />
            </View>

            <View
                style={{
                    flexDirection: 'row',
                    gap: 14,
                    marginTop: 18,
                }}
            >
                <Macro
                    label="Protein"
                    value={totals.protein}
                    goal={goals.protein}
                />
                <Macro
                    label="Carbs"
                    value={totals.carbs}
                    goal={goals.carbs}
                />
                <Macro
                    label="Fat"
                    value={totals.fat}
                    goal={goals.fat}
                />
            </View>
        </Card>
    )
}
